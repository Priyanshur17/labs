#include<stdio.h>
int solution(int arr1[],int i1,int e1,int arr2[],int i2,int e2){
	int n1= e1-i1;
	int n2=e2-i2;
	if(n1>n2){
		return solution(arr2,i2,e2,arr1,i1,e1);
	}
	if(n1==0){
		if(n2%2==1)
		return arr2[n2/2];
		else
		return (arr2[n2/2 -1]+arr2[n2/2])/2;
		
	}
	if(n1==1 && n2==1){
		return (arr1[0]+arr2[0])/2  ;
		
	}
	int mid1 = n1/2;
	int	mid2 = n2/2;
	if(arr1[mid1]<=arr2[mid2]){
		return solution(arr1,mid1+1,e2,arr2,i2,n2-mid1-1);
	}
	return solution(arr1,mid1+1,e1,arr2,mid2+1,e2);
}
int main(){
	int arr1[]={1,2,3,4,5};
	int arr2[]={6,7,8,9,10};
	int n1=(sizeof(arr1))/(sizeof(int));
	int n2=(sizeof(arr2))/(sizeof(int));
	int ans=solution(arr1,0,n1,arr2,0,n2);
	printf("%d",ans);
}
