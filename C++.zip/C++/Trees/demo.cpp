#include<iostream>
#include<queue>
using namespace std;
#include "treeUse.h"
TreeNode<int>* takeinputLevelWise(){
    int data;
    cout<<"Enter root data "<<endl;
    cin>>data;
    TreeNode<int>*root = new TreeNode<int>(data);
    queue<TreeNode<int>*> q;
    q.push(root);
    while(!q.empty()){
        TreeNode<int>* node = q.front();
        q.pop();
        cout<<"Enter the no. of child of "<<node->data<<endl;
        int n;
        cin>>n;
        for(int i =0 ;i<n;i++){
            cout<<"Enter the data of"<< i <<"th node of "<<node->data<<endl;
            int rdata;
            cin>>rdata;
            TreeNode<int>* child = new TreeNode<int>(rdata);
            node->children.push_back(child);
            q.push(child);
        }

    }
    return root;
}
TreeNode<int>* takeinput(){
    int rootData;
    cout<<"Enter Data"<<endl;
    cin>>rootData;
    TreeNode<int>*root = new TreeNode<int>(rootData);
    cout<<"Enter number of children of "<<rootData<<endl;
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        TreeNode<int>*child = takeinput();
        root->children.push_back(child);
    }
    return root;
}

void print_tree(TreeNode<int>* root){
    if(root==NULL){
        return;
    }
    cout<<root->data<<" :";
    for(int i=0;i<root->children.size();i++){
        cout<<root->children[i]->data<<",";
    }
    cout<<endl;
    for(int i=0;i<root->children.size();i++){
        print_tree(root->children[i]);
    }
}
void print_treeLevel(TreeNode<int>* root){
    if(root==NULL){
        return;
    }
    
    queue<TreeNode<int>*>q;
    q.push(root);
    while(!q.empty()){
        TreeNode<int>* node = q.front();
        cout<<node->data<<" :";
        q.pop();
        for(int i=0;i<node->children.size();i++){
            cout<<node->children[i]->data<<",";
            q.push(node->children[i]);
        }
        cout<<endl;
    }
}

int numNodes(TreeNode<int>* root){
    int ans=1;
    for(int i=0;i<root->children.size();i++){
        ans+= numNodes(root->children[i]);
    }
    return ans;
}



TreeNode<int> *maxDataNode(TreeNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return NULL;
    int max = root->data;
    TreeNode<int> *Node = root;
    for (int i = 0; i < root->children.size(); i++)
    {
        TreeNode<int> *temp = maxDataNode(root->children[i]);
        if (temp->data > max)
        {
            max = temp->data;
            Node = temp;
        }
    }
    return Node;
}



void getHeight(TreeNode<int> *root, int height, int *max)
{
    if ((*max) < height)
        *max = height;
    for (int i = 0; i < root->children.size(); i++)
        getHeight(root->children[i], 1 + height, max);
}
int getHeight(TreeNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return 0;
    int max = 1, height = 1;
    getHeight(root, height, &max);
    return max;
}


int getLeafNodeCount(TreeNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return 0;
    int count = 0;
    if (root->children.size() == 0)
        return 1;
    for (int i = 0; i < root->children.size(); i++)
        count = count + getLeafNodeCount(root->children[i]);
    return count;
}

void printPostOrder(TreeNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
    for (int i = 0; i < root->children.size(); i++)
        printPostOrder(root->children[i]);
    cout << root->data << " ";
}

void printPreOrder(TreeNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
     cout << root->data << " ";
    for (int i = 0; i < root->children.size(); i++)
        printPreOrder(root->children[i]);
    
}

void deleteTree(TreeNode<int> *root)
{
    // Write your code here
    if (root == NULL)
        return;
     
    for (int i = 0; i < root->children.size(); i++)
        deleteTree(root->children[i]);
    delete root;
}

void printAtLevelK(TreeNode<int> *root,int k){
    if(k==0){
        cout<<root->data<<endl;
        return;
    }
    for (int i = 0; i < root->children.size(); i++)
        printAtLevelK(root->children[i],k-1);
}

int main(){
    // TreeNode<int>* root = new TreeNode<int>(1);
    // TreeNode<int>* node1 = new TreeNode<int>(2);
    // TreeNode<int>* node2 = new TreeNode<int>(3);
    // TreeNode<int>* node3 = new TreeNode<int>(4);
    // root->children.push_back(node1);
    // root->children.push_back(node3);
    // node3->children.push_back(node2);
    TreeNode<int>* root = takeinputLevelWise();
    print_treeLevel(root);

    int n=numNodes(root);
    cout<<endl;
    cout<<"the total nodes are"<<n<<endl;


}