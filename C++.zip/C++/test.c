#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

#define MAX_BUF 1024

int main()
{
    int fd[2]; // file descriptors for the pipes
    char buf[MAX_BUF];
    pid_t pid;

    // create the pipes
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // fork a child process
    pid = fork();

    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {  // child process (server)
        close(fd[1]); // close the write end of the pipe

        // read filenames from the pipe
        char filename1[MAX_BUF], filename2[MAX_BUF];
        read(fd[0], filename1, MAX_BUF);
        read(fd[0], filename2, MAX_BUF);

        // open the files for reading
        FILE *file1 = fopen(filename1, "r");
        FILE *file2 = fopen(filename2, "r");

        if (file1 == NULL || file2 == NULL) {
            // error opening the files
            strcpy(buf, "Error: could not open one or both of the files.");
            write(fd[1], buf, strlen(buf) + 1);
            exit(EXIT_FAILURE);
        }

        // read and write lines from the files
        while (1) {
            char line1[MAX_BUF], line2[MAX_BUF];

            // read a line from file1
            if (fgets(line1, MAX_BUF, file1) == NULL)
                break;

            // read a line from file2
            if (fgets(line2, MAX_BUF, file2) == NULL)
                break;

            // write the lines to the pipe
            write(fd[1], line1, strlen(line1) + 1);
            write(fd[1], line2, strlen(line2) + 1);
        }

        // close the files and the pipe
        fclose(file1);
        fclose(file2);
        close(fd[0]);
        exit(EXIT_SUCCESS);
    } else {  // parent process (client)
        close(fd[0]); // close the read end of the pipe

        // read filenames from the standard input
        char filename1[MAX_BUF], filename2[MAX_BUF];
        printf("Enter filename1: ");
        fgets(filename1, MAX_BUF, stdin);
        filename1[strlen(filename1) - 1] = '\0'; // remove the newline character
        printf("Enter filename2: ");
        fgets(filename2, MAX_BUF, stdin);
        filename2[strlen(filename2) - 1] = '\0'; // remove the newline character

        // write the filenames to the pipe
        write(fd[1], filename1, strlen(filename1) + 1);
        write(fd[1], filename2, strlen(filename2) + 1);

        // read lines from the pipe and print them to the standard output
        while (1) {
            ssize_t num_bytes = read(fd[0], buf, MAX_BUF);

            if (num_bytes == -1) {
                perror("read");
                exit(EXIT_FAILURE);
            } else if (num_bytes == 0) {
                break;
            } else {
                printf("%s", buf);
            }
        }

        // close the pipe
        close(fd[1]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}