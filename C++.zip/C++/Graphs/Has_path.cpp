#include<bits/stdc++.h>
using namespace std;
const int N=1e5+2;
bool vis[N];
vector<int> adj[N];

bool dfs(int st,int e){
    vis[st]=true;
    for(auto it=adj[st].begin();it!=adj[st].end();it++){
        if(*it==e){
            return true ;
        }
        else if(!vis[*it] && dfs(*it,e)){
            return true;
        }
    }
    return false;
}
int main(){
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        vis[i]=false;
    }
    int x,y;
    for(int i=0;i<m;i++){
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int st;
    cin>>st;
    int e;
    cin>>e;
    if(dfs(st,e)){
        cout<<"yes"<<endl;
    }
    else
    cout<<"no"<<endl;
}