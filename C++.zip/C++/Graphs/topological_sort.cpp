#include<bits/stdc++.h>
using namespace std;
const int N = 1e5 + 2;
bool vis[N];
vector<int> adj[N];
void topological(int i, stack<int> &st)
{
    vis[i] = true;
    vector<int>::iterator it;
    for ( it = adj[i].begin(); it != adj[i].end();it++){
        if(!vis[*it]){
            topological(*it,st);
        }
    }
    st.push(i);
}
void topological_sort(int vertices)
{
    stack<int> st;
    for (int i = 0; i < vertices; i++)
    {
        if(!vis[i]){
            topological(i,st);
        }
    }
    fstream fp2;
    fp2.open("output.txt", ios:: out);
    while (!st.empty())
    {
        fp2 << st.top() << " ";
        st.pop();
    }
}

bool isCyclic_V(int v, bool visited[], bool *Stack)
{
    if (visited[v] == false)
    {

        visited[v] = true;
        Stack[v] = true;

        vector<int>::iterator it;
        for (it = adj[v].begin(); it != adj[v].end(); it++)
        {
            if (!visited[*it] && isCyclic_V(*it, visited, Stack))
                return true;
            else if (Stack[*it])
                return true;
        }
    }

    Stack[v] = false;
    return false;
}

bool isCyclic(int V){
    bool *visited = new bool[V];
    bool *Stack = new bool[V];
    for (int i = 0; i < V; i++)
    {
        visited[i] = false;
        Stack[i] = false;
    }

    
    for (int i = 0; i < V; i++)
        if (!visited[i] && isCyclic_V(i, visited, Stack))
            return true;

    return false;
}



int main(){
    int n, m;
    fstream fp;
    fp.open("input.txt", ios::in);
    fp>>n>>m;
    for (int i = 0; i < n;i++){
        vis[i] = false;
    }
    int x, y;
    
    
    for (int i = 0; i < m; i++)
    {
        fp >> x >> y;
        adj[x].push_back(y);
        // adj[y].push_back(x);
    }
    fp.close();
    fstream fp1;
    fp1.open("output.txt", ios::out);
    if (!isCyclic(n))
        topological_sort(n);
    else{
    fp1 << "Given Graph is cyclic";
    }
    fp1.close();
}