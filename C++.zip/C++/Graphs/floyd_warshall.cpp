#include<bits/stdc++.h>
using namespace std;
const int inf=1e9;
int main(){
    vector<vector<int>> graph = {{inf,6,6,4,7},
                                {4,5,0,1,inf},
                                {inf,inf,8,0,1},
                                {4,inf,0,0,inf}};
    
    vector<vector<int>> dist =graph;
    int n = graph.size();
    for(int k=0;k<n;k++){
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                if((dist[i][k]+dist[k][j]) < dist[i][j] ){
                    dist[i][j]=dist[i][k]+dist[k][j];
                }
            }
        }
    }

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(dist[i][j]==inf){
                cout<<"INF"<<" ";
            }
            else
            cout<<dist[i][j]<<" ";
        }
        cout<<"\n";
    }
}