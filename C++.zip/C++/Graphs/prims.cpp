
#include<iostream>
using namespace std;
#include <bits/stdc++.h>
#define V 5
int minKey(int key[], bool mstSet[])
{
	int min = INT_MAX, min_index;

	for (int v = 0; v < V; v++)
		if (mstSet[v] == false && key[v] < min)
			min = key[v], min_index = v;

	return min_index;
}




void spanning_tree(int k,int graph[V][V])
{   

	int parent[V];
	
	int key[V];

	bool mstSet[V];

	for (int i = 0; i < V; i++)
		key[i] = INT_MAX, mstSet[i] = false;

	
	key[0] = 0;
	parent[0] = -1; 

	
	for (int count = 0; count < V - 1; count++) {
		
		int u = minKey(key, mstSet);

		mstSet[u] = true;

		
		for (int v = 0; v < V; v++)

			
			if (graph[u][v] && mstSet[v] == false
				&& graph[u][v] < key[v])
				parent[v] = u, key[v] = graph[u][v];
	}
	int sum =0;
	fstream fp2;
    fp2.open("output.txt", ios:: out);
	fp2<<"Edge \tWeight\n";
		
	for (int i = 1; i < V; i++){
		sum= sum+ graph[i][parent[i]];
		fp2<<parent[i]<< " - " << i <<"\t"<<graph[i][parent[i]]<< "\n";
			
	}
	
	fp2<<"The mst weight is "<<sum<<endl;
	fp2.close();
}


int main()
{
	// int graph[V][V] = { { 0,0,9,0,10},
	// 					{ 0,0,0,7,6 },
	// 					{ 9,0,0,8,11},
	// 					{ 0,7,8,0,12},
	// 					{ 10,6,11,12,0} };

	int graph[V][V];
	fstream fp;
    fp.open("input.txt", ios:: in);
	for(int i=0;i<V;i++){
		for(int j=0;j<V;j++){
			int x;
			fp>>x;
			graph[i][j]=x;
		}
	}
	fp.close();

	
	spanning_tree(V,graph);

	return 0;
}
