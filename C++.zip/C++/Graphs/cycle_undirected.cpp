#include <bits/stdc++.h>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

const int N = 1e5 + 2;
// int dis[N];
vector<int> adj[N];
bool isCyclic_V(int s,int V,vector<bool> &visited){
    vector<int> parent(V, -1);


    queue<int> q;

    visited[s] = true;
    q.push(s);

    while (!q.empty())
    {

        
        int u = q.front();
        q.pop();
        
        vector<int>::iterator it;
        for (it = adj[u].begin(); it != adj[u].end(); it++)
        {
            if (!visited[*it])
            {
                visited[*it] = true;
                q.push(*it);
                parent[*it] = u;
            }
            else if (parent[*it] != u)
                return true;
        }
    }
    return false;
}

bool isCyclic(int V){
    vector<bool> visited(V, false);

    for (int i = 0; i < V; i++)
        if (!visited[i] && isCyclic_V( i,V, visited))
            return true;
    return false;
}
int main(){
    int n, m;
    fstream fp;
    fp.open("input.txt", ios::in);
    fp >> n >> m;

    int x, y;

    for (int i = 0; i < m; i++)
    {
        fp >> x >> y;
        adj[x].push_back(y);
         adj[y].push_back(x);
    }
    if(isCyclic(n)){
         cout << "Cyclic" << endl;
    }
    else
         cout << "Acyclic" << endl;
}