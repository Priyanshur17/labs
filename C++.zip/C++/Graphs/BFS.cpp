#include<bits/stdc++.h>
#include <iostream>
#include<queue>
#include<vector>
using namespace std;

const int N = 1e5+2;
// int dis[N];
bool vis[N];
vector<int> adj[N];

int main(){
    // for(int i=0;i<N;i++){
    //     dis[i]=INT_MAX;
    // }
    for(int i=0;i<N;i++){
        vis[i]=false;
    }

    int n,m;
    cin>>n >>m;
    int x,y;
    for(int i=0;i<m;i++){
        cin>> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    queue<int> q;
    q.push(1);  // fisrt input any vertex from where you want BFS
    vis[1]=true;

    while (!q.empty())
    {
        int node = q.front();
        q.pop();
        cout<< node << endl;
        

        vector<int> :: iterator it;
        for(it=adj[node].begin(); it!=adj[node].end();it++){
            // if(dis[node]+1<dis[*it]){
            //     dis[*it]=dis[node]+1;
            //     q.push(*it);
            // }
            if(!vis[*it]){
                vis[*it]=true;
                q.push(*it);
            }
            }
        }

    // for(int i =0 ; i<n;i++){
    //     cout<<dis[i]<<endl;
    // }
    
    return 0;
}