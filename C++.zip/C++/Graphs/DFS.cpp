#include<bits/stdc++.h>
using namespace std;

const int N = 1e5+2;
// int dis[N];
bool vis[N];
vector<int> adj[N];
void dfs(int i){
    vis[i]=true;
    cout<<i<<" ";
    for(auto it=adj[i].begin();it!=adj[i].end();it++){
        if(!vis[*it]){
            dfs(*it);
        }
    }
}
void DFS(int vertices){
    for(int i=0;i<vertices;i++){
        if(!vis[i]){
            dfs(i);
        }
    }
}
int main(){
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        vis[i]=false;
    }
    int x,y;
    for(int i=0;i<m;i++){
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);

    }
    // dfs(0);
    DFS(n);
}