
#include<bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int n; cin>>n;
        vector<int>ans,vi(n);
       
        for( int k=0;k<n;k++){
            cin>>vi[k];
        }
        ans.push_back(vi[0]);
        int cnt=1;
      
        for( int k=1;k<n;k++){
            if(vi[k]>=vi[k-1]){
                ans.push_back(vi[k]);
                cnt++;
            }
            else{
                ans.push_back(vi[k]);
                ans.push_back(vi[k]);
                cnt+=2;
            }
            
        }
        cout<<cnt<<endl;
        for(int i=0;i<ans.size();i++)cout<<ans[i]<<" ";
        
    }
    return 0;
}