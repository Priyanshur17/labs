#include <bits/stdc++.h>

using namespace std;

const int N = 1e5+2;

vector<int> adj[N];
bool visited[N];
int tin[N];
int low[N];
int timer;
vector<pair<int, int>> bridges;

void dfs(int u, int p) {
    visited[u] = true;
    tin[u] = low[u] = timer++;
    for (int v : adj[u]) {
        if (v == p) continue;
        if (visited[v]) {
            low[u] = min(low[u], tin[v]);
        } else {
            dfs(v, u);
            low[u] = min(low[u], low[v]);
            if (low[v] > tin[u]) {
                bridges.push_back(make_pair(u, v));
            }
        }
    }
}

void findBridges(int n) {
    timer = 0;
    for (int i = 0; i < n; i++) {
        visited[i] = false;
    }
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            dfs(i, -1);
        }
    }
}

int main() {
    int n, m;
    fstream fp;
    fp.open("input.txt", ios:: in);
    fp >> n >> m;
    for (int i = 0; i < m; i++) {
        int u, v;
        fp >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    fp.close();
    fstream fp2;
    fp2.open("output.txt", ios:: out);
    findBridges(n);
    for (pair<int, int> bridge : bridges) {
        fp2 << "Bridge: " << bridge.first << " " << bridge.second << endl;
    }
    return 0;
}
