#include<bits/stdc++.h>
using namespace std;
vector<vector<int>> adj;
vector<bool> vis;
vector<int> col;
bool biparte=true;
void color(int u,int curr){
    if(col[u]!=-1 and col[u]!=curr){
        biparte=false;
        return ;
    }
    col[u]=curr;
    if(vis[u]){
        return;
    }
    vis[u]=true;
    for(auto i : adj[u]){
        color(i,curr xor 1);
    }
}
int main(){
    int n,m;
    cin>>n>>m;
    adj = vector<vector<int>>(n);
    vis=vector<bool>(n,false);
    col=vector<int>(n,-1);
    int u,v;
    for(int i=0;i<m;i++){
        
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);

    }
    for(int i=0;i<n;i++){
        if(!vis[i]){
            color(i,0);
        }
    }
    if(biparte){
        cout<<"graph is bipartite";
    }
    else
    cout<<"graph is not bipartite";
}