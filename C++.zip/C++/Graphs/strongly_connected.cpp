#include <bits/stdc++.h>

using namespace std;

const int N = 1e5+2;

vector<int> adj[N];
vector<int> radj[N];
bool visited[N];
stack<int> st;
vector<vector<int>> scc;

void dfs1(int u) {
    visited[u] = true;
    for (int v : adj[u]) {
        if (!visited[v]) {
            dfs1(v);
        }
    }
    st.push(u);
}

void dfs2(int u, vector<int>& component) {
    visited[u] = true;
    component.push_back(u);
    for (int v : radj[u]) {
        if (!visited[v]) {
            dfs2(v, component);
        }
    }
}

void findSCCs(int n) {
    for (int i = 0; i < n; i++) {
        visited[i] = false;
    }
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            dfs1(i);
        }
    }
    for (int i = 0; i < n; i++) {
        visited[i] = false;
    }
    while (!st.empty()) {
        int u = st.top();
        st.pop();
        if (!visited[u]) {
            vector<int> component;
            dfs2(u, component);
            scc.push_back(component);
        }
    }
}

int main() {
    int n, m;
    fstream fp;
    fp.open("input.txt", ios:: in);
    fp >> n >> m;
    for (int i = 0; i < m; i++) {
        int u, v;
        fp >> u >> v;
        adj[u].push_back(v);
        radj[v].push_back(u);
    }
    fp.close();
    findSCCs(n);
    fstream fp2;
    fp2.open("output.txt", ios:: out);
    for (vector<int> component : scc) {
        fp2 << "SCC:";
        for (int u : component) {
            fp2 << " " << u;
        }
        fp2 << endl;
    }
    fp2.close();
    return 0;
}
