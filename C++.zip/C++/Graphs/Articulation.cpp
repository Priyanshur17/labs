#include <bits/stdc++.h>

using namespace std;

const int N = 1e5+2;

vector<int> adj[N];
bool visited[N];
int disc[N], low[N], parent[N];
bool ap[N];
int timer = 0;

void dfs(int u) {
    visited[u] = true;
    disc[u] = low[u] = ++timer;
    int children = 0;
    for (int v : adj[u]) {
        if (!visited[v]) {
            children++;
            parent[v] = u;
            dfs(v);
            low[u] = min(low[u], low[v]);
            if (parent[u] == -1 && children > 1) {
                ap[u] = true;
            }
            if (parent[u] != -1 && low[v] >= disc[u]) {
                ap[u] = true;
            }
        } else if (v != parent[u]) {
            low[u] = min(low[u], disc[v]);
        }
    }
}

void findArtPoints(int n) {
    timer = 0;
    for (int i = 0; i < n; i++) {
        visited[i] = false;
        parent[i] = -1;
        ap[i] = false;
    }
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            dfs(i);
        }
    }
    fstream fp2;
    fp2.open("output.txt", ios:: out);
    for (int i = 0; i < n; i++) {
        if (ap[i]) {
            fp2 << i << " ";
        }
    }
    fp2.close();
}

int main() {
    int n, m;
    fstream fp;
    fp.open("input.txt", ios::in);
    fp >> n >> m;
    for (int i = 0; i < m; i++) {
        int u, v;
        fp >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    fp.close();
    findArtPoints(n);
    return 0;
}
