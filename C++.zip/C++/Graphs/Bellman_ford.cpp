#include<bits/stdc++.h>
using namespace std;
const int inf=1e7;
int main(){
    int n,m;cin>>n>>m;
    vector<vector<int>> edges;
    for(int i=0;i<m;i++){
        int u,v,w;
        cin>>u>>v>>w;
        edges.push_back({u,v,w});
    }
    vector<int> dis(n,inf);
    int source;
    cout<<"enter source"<<endl;
    cin>>source;
    dis[source]=0;
    for(int i=0;i<n-1; i++)//n;
    {
        for(auto x: edges){
            //for negative cycle 
            //bool change=false;
            int u=x[0];
            int v=x[1];
            int w=x[2];
            //if(dis[v]>w+dis[u])
            //change = true;
            dis[v]=min(dis[v],dis[u]+w);

        }
    }
    for(auto x:dis){
        cout<<x<<endl;
    }
}