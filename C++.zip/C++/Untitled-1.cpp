#include <bits/stdc++.h>
using namespace std;
 vector<vector<int>> findMatrix(vector<int>& nums) {
        sort(nums.begin(),nums.end());
        vector<vector<int>> v;
        v.push_back({});
        v[0].push_back(nums[0]);
        int pre=nums[0];
        int count=0;
        for(int i=1;i<nums.size();i++){
            if(nums[i]==pre){
            count++;
                v[count].push_back(nums[i]);
                pre=nums[i];
            }
            else {
                count=0;
                v[count].push_back(nums[i]);
                pre=nums[i];
            }
        }
        return v;
    }
int main(){
    vector<int> nums;
    int n;
    int x;
    while(n--){
        cin>>x;
        nums.push_back(x);
    }
    vector<vector<int>> vec=findMatrix(nums);
    for (int i = 0; i < vec.size(); i++) {
        for (int j = 0; j < vec[i].size(); j++)
            cout << vec[i][j] << " ";
        cout << endl;
    }
    return 0;
    
}