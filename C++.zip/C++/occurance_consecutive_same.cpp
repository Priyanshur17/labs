#include <iostream>
using namespace std;
int main()
{ // i,e,, 10 10 10 6 6 6 77 77 8 9
    int currVal, val;
    if (cin >> currVal)
    {
        int cnt = 1;
        while (cin >> val)
        {
            if (val == currVal)
                cnt++;
            else
            {
                cout << currVal << " occurs " << cnt << "times" << endl;
                currVal = val;
                cnt = 1;
            }
        }

        cout << currVal << " occurs " << cnt << " times " << endl;
    }
    return 0;
}
