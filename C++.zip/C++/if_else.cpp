#include <iostream>
using namespace std;
int main()
{
    int n;
    cout << "Enter the number ." << endl;
    cin >> n;
    if (n > 10)
    {
        cout << "The number is greater than 10.";
    }
    else if (n < 10)
    {
        cout << "The number is less than 10.";
    }
    else
    {
        cout << "The number is equal to 10.";
    }
    return 0;
}
