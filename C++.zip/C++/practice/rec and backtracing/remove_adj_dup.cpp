#include<iostream>
using namespace std;
void remove_adj(char s[]){
    if(s[0]=='\0'){
        return ;
    }
    if(s[0]==s[1]){
        int i=1;
        for(;s[i]!='\0';i++){
            s[i-1]=s[i];
        }
        s[i-1]=s[i];
        remove_adj(s);
    }
    remove_adj(s+1);

}
int main(){
    char str[100];
    cin>>str;
    remove_adj(str);
    cout<<str;
}