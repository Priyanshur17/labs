#include<iostream>
using namespace std;
void generate_brac(string output,int n,int open,int close){
    if(output.length()==2*n){
        cout<<output<<endl;
        return;
    }
    if(open<n){
        generate_brac(output+'(',n,open+1,close);
    }
    if(close<open){
        generate_brac(output+')',n,open,close+1);
        
    }
    return ;
    
}
int main(){
    string output="";
    int n;
    cin>>n;
    generate_brac(output,n,0,0);
    
}