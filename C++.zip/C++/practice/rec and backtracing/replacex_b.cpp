#include<iostream>
using namespace std;
void removeX(char s[]){
    if(s[0]=='\0'){
        return;
    }
    if(s[0]!='x'){
        removeX(s+1);
    }
    else{
        s[0]='b';
        removeX(s+1);
    }

}
int main(){
    char str[100];
    cin>>str;
    removeX(str);
    cout<<str;
}