#include<bits/stdc++.h>
using namespace std;
#define N 9
//for checking empty space in grid for filling
bool isEmpty(int grid[N][N],int &row,int &col){
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            if(grid[i][j]==0){
                row=i;
                col=j;
                return true;
            }
        }
    }
    return false;

}
bool isSafeInBlock(int grid[N][N],int row,int col,int num){
    int rowfactor= row - (row%3);
    int colFactor= col - (col%3);
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            if(grid[rowfactor+i][colFactor+j]==num){
                return false;
            }
        }
    }
    return true;
}

bool isSafeInRow(int grid[N][N],int row,int num){
    for(int i=0;i<N;i++){
        if(grid[row][i]==num){
            return false;
        }
    }
    return true;
}
bool isSafeInColumn(int grid[N][N],int col,int num){
    for(int j=0;j<N;j++){
        if(grid[j][col]==num){
            return false;
        }
    }
    return true;
}

bool isSafe(int grid[N][N],int row,int col,int num){
    if(isSafeInBlock(grid,row,col,num) && isSafeInColumn(grid,col,num) && isSafeInRow(grid,row,num)){
        return true;
    }
    return false;
}


bool sudokoSolver(int grid[N][N]){
    int row,col;
    if(!isEmpty(grid,row,col)){
        return true;
    }
    for(int i=1;i<=N;i++){
        if(isSafe(grid,row,col,i)){
            grid[row][col]=i;
            if(sudokoSolver(grid)){
                return true;
            }
            grid[row][col]=0;
        }
    }
    return false;
}


int main(){
    int grid[N][N];
    
    for(int i=0;i<N;i++){
        string input;
        cin>>input;
        for(int j=0;j<N;j++){
            grid[i][j]= input[j]-'0';
        }
    }
    
    sudokoSolver(grid);
    cout<<endl;
    cout<<endl;
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            cout<<grid[i][j];
        }
        cout<<endl;
    }
}