#include<bits/stdc++.h>
using namespace std;
#define M 3
void printsolution(int** solution, int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<solution[i][j]<<" ";
        }cout<<endl;
       
    }
    cout<<endl;
    cout<<endl;
}
void mazehelp(int maze[M][M],int** solution,int n,int x,int y){
    if(x==n-1 && y==n-1){
        solution[x][y]=1;
        printsolution(solution,n);
        return;
    }
    if(x>=n || x<0 || y<0 || y>=n || maze[x][y]==0 || solution[x][y]==1){
        return;
    }
    solution[x][y]=1;
    mazehelp(maze,solution,n,x-1,y);
    mazehelp(maze,solution,n,x+1,y);
    mazehelp(maze,solution,n,x,y-1);
    mazehelp(maze,solution,n,x,y+1);
    solution[x][y]=0;
    
}
void ratInmaze(int maze[M][M],int n){
    int** solution = new int*[n];
    for(int i=0;i<n;i++){
        solution[i] = new int[n];
    }
    for(int i=0;i<M;i++){
        for(int j=0;j<M;j++){
            solution[i][j]=0;
        }
     
    }
    mazehelp(maze,solution,n,0,0);
}
int main(){
 
 int maze[M][M];
 
 for(int i=0;i<M;i++){
        for(int j=0;j<M;j++){
            cin>>maze[i][j];
        }
        
    }
    ratInmaze(maze,M);
}