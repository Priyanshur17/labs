#include<iostream>
using namespace std;
void genrate_string(string input,string output,int i){
    if(input[i]=='\0'){
        cout<<output<<endl;
        return ;
    }
    //considering one digit
    int digit=input[i]-'0';
    char ch= digit+'A'-1;
    
    genrate_string(input,output+ch,i+1);
    //considering two at atime digits
    if(input[i+1]!='\0'){
        int secoddigit= input[i+1]-'0';
        int no = (digit*10) + secoddigit;
        if(no<=26){
            char rh = no+'A'-1;
           
            genrate_string(input,output+rh,i+2);
        }
        
    }
    return;
}
int main(){
    string input;
    cin>>input;
    string output="";
    genrate_string(input,output,0);
    

}