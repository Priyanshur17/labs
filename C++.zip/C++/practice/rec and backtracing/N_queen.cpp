#include<bits/stdc++.h>
using namespace std;
int board[11][11];
bool isPossible(int n, int row,int column){
    //check below column
    for(int i=row-1;i>=0;i--){
        if(board[i][column]==1)
        return false;
    }
    //diagonally below left
    for(int i=row-1,j=column-1; i>=0 && j>=0;j--,i--){
        if(board[i][j]==1){
            return false;
        }
    }
    // diagonally below right
    for(int i=row-1,j=column+1; i>=0 && j<n;j++,i--){
        if(board[i][j]==1){
            return false;
        }
    }
    
    return true;
}
void nQueenHelper(int n,int row){
    if(n==row){
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                cout<<board[i][j]<<" ";
            }
        }
        cout<<endl;
        return;
    }
    // Place at all possible position
    for(int j=0;j<n;j++){
        if(isPossible(n,row,j)){
            board[row][j]= 1;
            nQueenHelper(n,row+1);
            board[row][j]=0;
        }
        
    }
    return;
}
void nQueenPlace(int n){
    memset(board,0,11*11*sizeof(int));
    nQueenHelper(n,0);
}
int main(){
    int n;
    cin>>n;
    nQueenPlace(n);
}
