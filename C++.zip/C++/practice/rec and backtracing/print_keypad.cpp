#include<iostream>
using namespace std;
void print_keypad(int num,string output){
    string input;
    if(num == 0){
        cout<<output<<endl;
        return ;
    }
    
        int n = num%10;
        num = num/10;
        
        switch(n){
            case 2: input = "abc";
                break;
            case 3: input = "def";
                break;
            case 4: input = "ghi";
                break;
            case 5: input = "jkl";
                break;
            case 6: input = "mno";
                break;
            case 7: input = "pqrs";
                break;
            case 8: input = "tuv";
                break;
            case 9: input = "wxyz";
                break;             
    }
    
     if(n==7 or n==9){
    print_keypad(num,output+input[0]);
    print_keypad(num,output+input[1]);
    print_keypad(num,output+input[2]);
    print_keypad(num,output+input[3]);
    }
    else{
    print_keypad(num,output+input[0]);
    print_keypad(num,output+input[1]);
    print_keypad(num,output+input[2]);
    }
}
int main(){
    int n;
    cin>>n;
    string output= "";
    print_keypad(n,output);

}