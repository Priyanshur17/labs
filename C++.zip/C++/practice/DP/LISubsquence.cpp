#include<bits/stdc++.h>
using namespace std;
int LISq(int n,int arr[]){
    int *output=new int[n];
    output[0]=1;
    for(int i=1;i<n;i++){
        output[i]=1;
        for(int j=i-1;j>=0;j--){
            if(arr[j]>arr[i]){
                continue;
            }
            int poss_ans= 1+output[j];
            if(poss_ans>=output[i]){
                output[i]=poss_ans;
            }
        }
    }
    int ans=0;
    for(int i=0;i<n;i++){
        if(output[i]>ans){
            ans=output[i];
        }
    }
    
    delete [] output;
    return ans;
   
}

int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<LISq(n,arr);
}