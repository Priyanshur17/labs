#include<bits/stdc++.h>
using namespace std;

//DP iterative
int minStepOneB(int n){
    if(n<=1){
        return 0;
    }
    int *arr=new int[n+1];
    arr[1]=0;
    arr[2]=1;
    arr[3]=1;
    int b,c;
    for(int i=4;i<n+1;i++){
        b=c=n;
        if(i%2==0)b=arr[i/2];
        if(i%3==0)c=arr[i/3];
        arr[i]= 1+ min(arr[i-1],min(b,c));
    }
    int ans=arr[n];
    delete [] arr;
    return ans;
}

//DP memorization
int minStepOneA(int n,int *arr){
    if(n<=1){
        return 0;
    }
    if(arr[n]!=-1){
        return arr[n];
    }
    int y=INT_MAX;
    int z=INT_MAX;
    int x =minStepOneA(n-1,arr);
    if(n%2==0){
        y=minStepOneA(n/2,arr);
    }
    if(n%3==0){
        z=minStepOneA(n/3,arr);

    }
    int output = 1+min(x,min(y,z));
    arr[n]=output;
    return output;

}

//recursion
int minStepOne(int n){
    if(n<=1){
        return 0;
    }
    int y=INT_MAX;
    int z=INT_MAX;
    int x =minStepOne(n-1);
    if(n%2==0){
        y=minStepOne(n/2);
    }
    if(n%3==0){
        z=minStepOne(n/3);

    }

    return 1+ min(x,min(y,z));
}
int main(){
    int n;
    cin>>n;
    int *arr= new int[n+1];
    for(int i=0 ;i<n+1 ;i++)
        arr[i]=-1;
    int ans = minStepOneA(n,arr);
    cout<<ans <<endl;
}