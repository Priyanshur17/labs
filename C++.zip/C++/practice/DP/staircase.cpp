#include<iostream>
using namespace std;
///like fibonacci code
void staircase(int n){
    int *arr=new int[n+1];
    arr[0]=1;
    arr[1]=1;
    arr[2]=2;
    for(int i=3;i<n+1;i++){
        arr[i]=arr[i-1]+arr[i-2]+arr[i-3];
    }
    int ans= arr[n];
    delete [] arr;
    cout<< ans;
}
// void staircase(int n,int &count){
//     if(n==0){
//         count+=1;
//     }
//     if(n<0){
//         return ;
//     }
//     staircase(n-1,count);
//     staircase(n-2,count);
//     staircase(n-3,count);   
// }
int main(){
    int n;
    cin>>n;
    // int count=0;
    // staircase(n,count);
    // cout<<count<<endl;
    staircase(n);
}