#include <stdio.h>
int main()
{
	int n,i,j,a[10],swap;
	printf("Enter n : ");
	scanf("%d",&n);
	
	printf("enter elements of your array :");
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	
	printf("The sorted array is as follow :");
	
	for(i=0; i<n; i++){
		for(j=i+1; j<n; j++){
			if(a[i]>a[j]){
				swap=a[i];
				a[i]=a[j];
				a[j]=swap;
			}
		}
	}
	printf("The sorted array is as :");
	
	for(i=0; i<n ;i++){
		printf("%d/t",a[i]);
	}
	return 0;
}