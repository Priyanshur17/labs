#include <iostream>
#include <stack>
using namespace std;
class Queue
{
    stack<int> s1;

public:
    void Enqueue(int x)
    {
        s1.push(x);
    }
    int Dequeue()
    {
        if (s1.empty())
        {
            cout << "Queue is empty";
            return -00;
        }
        int x = s1.top();
        s1.pop();
        if (s1.empty())
        {
            return x;
        }
        int item = Dequeue();
        s1.push(x);
        return item;
    }
};

int main()
{
    Queue q;
    q.Enqueue(1);
    q.Enqueue(2);
    q.Enqueue(3);
    q.Enqueue(4);

    
    cout << q.Dequeue() << endl;
    cout << q.Dequeue() << endl;
    cout << q.Dequeue() << endl;
    cout << q.Dequeue() << endl;
    
    
    return 0;
    ;
}