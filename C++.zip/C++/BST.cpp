#include<iostream>
#include<queue>
using namespace std;

struct node{
    int data;
    node* left;
    node* right;

    node(int value){
        data = value;
        left = NULL;
        right = NULL;
    }
};
node* insertInBST(node* root,int key){
    if(root == NULL){
        return new node(key);
    }
    if(key>root->data){
        root->right = insertInBST(root->right,key);
    }
    else{
        root ->left = insertInBST(root->left,key);
    }
    return root;
}

void inorder(node* root){
    if (root == NULL){
        return;
    }
    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
node* inorderSucc(node* root){
    node* temp = root;
    while(temp && temp->left!=NULL){
        temp = temp->left;
    }
    return temp;
}
bool searchInBST(node* root,int key){
    if(root == NULL){
        return false;
    }
    if (root->data == key){
        return root;
    }
    else if ( root->data > key){
       return  searchInBST(root->left,key);
    }
    return searchInBST(root->right,key);
}

node* deleteInBST(node* root,int key){
    if (root->data > key){
        root->left = deleteInBST(root->left,key);
    }
    else if (root->data < key){
        root->right = deleteInBST(root->right,key);
    }
    else{
        if(root->left == NULL){
            node* temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL){
            node* temp = root->left;
            free(root);
            return temp;
        }

        node* temp = inorderSucc(root->right);
        root->data = temp ->data;
        root->right = deleteInBST(root->right,temp->data);
    }
    return root;
}

void levelorder(node* root){
    if(root == NULL){
        return;
    }
    queue<node*> q;
    q.push(root);
    q.push(NULL);
    while(!q.empty()){
        node* node = q.front();
        q.pop();
        if(node!=NULL){
            cout<<node->data<<" ";
            if(node->left){
                q.push(node->left);
            }
            if(node->right){
                q.push(node->right);
            }
        }
        else if(!q.empty()){
            q.push(NULL);
        }
    }
}
int main(){
    node* root = NULL;
    root =insertInBST(root,5);
    insertInBST(root,1);
    insertInBST(root,3);
    insertInBST(root,4);
    insertInBST(root,2);
    insertInBST(root,7);
    levelorder(root);
    if(searchInBST(root,5)){
        deleteInBST(root,5);
    }
    else{
        cout<<"This element is not pesent in BST\nThe inorder of BST is : ";
    }

    
}