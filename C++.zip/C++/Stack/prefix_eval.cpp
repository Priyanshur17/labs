#include<iostream>
#include<stack>
#include<math.h>
using namespace std;
int prefix_evaluation(string s){
    stack<int> st;
    for(int i =s.length()-1; i>=0;i--){
        if(s[i]>='0' && s[i]<='9'){
            st.push(s[i]-'0');
        }
        else{
            int oprd1=st.top();
            st.pop();
            int oprd2=st.top();
            st.pop();
            switch (s[i])
            {
            case '+':
                st.push(oprd1+oprd2);
                break;
            case '-':
                st.push(oprd1-oprd2);
                break;
            case '*':
                st.push(oprd1*oprd2);
                break;
            case '^':
                st.push(pow(oprd1,oprd2));
                break;
            case '/':
                st.push(oprd1/oprd2);
                break;
            
            }
        }
    }
    return st.top();
}

int main(){
    cout<<prefix_evaluation("-+7*45+20");
    return 0;
}