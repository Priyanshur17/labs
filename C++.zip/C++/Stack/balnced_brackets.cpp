#include <bits/stdc++.h>
using namespace std;
bool areBracketsBalanced(string input)
{
   stack<char> sample;
   for (int i = 0; i < input.length(); i++) {
       if (sample.empty()) {
           sample.push(input[i]);
       }
       else if ((sample.top() == '(' && input[i] == ')')
                || (sample.top() == '{' && input[i] == '}')
                || (sample.top() == '[' && input[i] == ']')) {
           sample.pop();
       }
       else {
           sample.push(input[i]);
       }
   }
   if (sample.empty()) {
       return true;
   }
   return false;
}
int main()
{
   string input;
   cout<<"enter the string";
   cin>>input;
   if (areBracketsBalanced(input))
       cout << "Balanced";
   else
       cout << "Not Balanced";
   return 0;
}
