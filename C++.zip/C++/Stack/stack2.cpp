#include<iostream>
#include<bits/stdc++.h>
using namespace std;
struct node
{
    int data;
    node* next;
};

class mystack{
    node* head;
    public:
    
    mystack(){
        head=NULL;
    }
    void push(int x){
        node* newnode = new node();
        newnode->data=x;
        newnode->next=head;
        head=newnode;
    }
    void pop(){
        node* todelete=head;
        if(head==NULL){
            cout<<"stack is already empty";
            return;
        }
        head=head->next;
        delete todelete;
    }
    int top(){
        if(head==NULL){
            cout<<"empty stack";
            return -1;
        }
        return head->data;
    }
    bool empty(){
        return head==NULL;
    }

};

int main(){
   mystack s;
   s.push(1);
   s.push(2);
   s.push(3);
   cout<<s.top()<<endl;
   s.pop();
   s.pop();
   cout<<s.top()<<endl;
   s.pop();
   cout<<s.top()<<endl;
   cout<<s.empty()<<endl;

    
    return 0;
}


//  #include<iostream>
// #include<bits/stdc++.h>
// using namespace std;
// class node{
     
//     public:
//    int data;
//     node* next;
//     node(int value){
//         data = value;
//         next = NULL;
//     }
//     void push(node* &head,int x){
//         node* newnode = new node(x);
//         newnode->next=head;
//         head=newnode;
//     }
//     void pop(node* &head){
//         node* todelete=head;
//         if(head==NULL){
//             cout<<"stack is already empty";
//             return;
//         }
//         head=head->next;
//         delete todelete;
//     }
//     int top(node* head){
//         if(head==NULL){
//             cout<<"empty stack";
//             return -1;
//         }
//         return head->data;
//     }
//     bool empty(node* head){
//         return head==NULL;
//     }

// };

// int main(){
//     node* st=NULL;//stack
//     st->push(st,1);
//     st->push(st,2);
//     st->push(st,3);
//     cout<<st->top(st)<<endl;
//     st->pop(st);
//     cout<<st->top(st)<<endl;
//     cout<<st->empty(st);
    
    
//     return 0;
// }