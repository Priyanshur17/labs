#include <iostream>
int main()
{
    int sum=0, value=0;
    std::cout << " Enter the numbers of which sum you want, after enteing hit '='  ";
    while( std::cin >> value )
        sum += value;
    
    std::cout <<" The sum of numbers input by the user is :" << sum ;
    return 0;
}