#include <iostream>
using namespace std;
#include <cmath>

bool isPrime(int num){
	int i;
	for(i=2;i<=sqrt(num);i++){
		if (num%i==0){
			return false;
		}
		return true;
	}
}

int main(){
	int a,b,i;
	cout<<"Enter the numbers between them you want to find all Prime numbers"<<endl;
	cin>>a>>b;
	
	for(i=a; i<=b ; i++){
		if(isPrime(i)){
			cout<<i<<endl;
		}
	}
	return 0;
}
