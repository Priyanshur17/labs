#include<iostream>
using namespace std;
int fact(int num){
	int factorial=1;
	for(int i=2; i<=num; i++){
		factorial*=i;
	}
	return factorial;
}

int main(){
	int n,r,nCr;
	cout<<"Enter n and r values : ";
	cin>>n>>r;
	
	nCr= fact(n)/(fact(n-r)*fact(r));
	cout<<"The value of your nCr is : "<<nCr<<endl;
	
}
