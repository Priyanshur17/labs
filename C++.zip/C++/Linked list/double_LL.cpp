#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class node{
    public:
    int data;
    node* next;
    node* prev;

    node(int value){
        data = value;
        next = NULL;
        prev = NULL;
    }
};
void deleteHead(node* &head){
    node* todelete=head;
    head=head->next;
    head->prev=NULL;

    delete todelete;
}

void deletion(node* &head,int pos){
    node* temp = head;
    if (pos==1){
        deleteHead(head);
        return;
    }
    int count =1;
    while(temp!= NULL && count!=pos){
        temp=temp->next;
        count++;
    }
    temp->next->prev=temp->prev;
    if(temp->next!=NULL){
    temp->prev->next=temp->next;
    }
    delete temp;
}

void insertatHead(node* &head,int value){
    node* n = new node(value);
    n->next=head;
    if (head!=NULL){
        head->prev=n;
    }
    head=n;

}

void insertatTail(node * &head,int value){
    if (head==NULL){
        insertatHead(head,value);
        return;
    }
    node* n = new node(value);
    node* temp = head;
    while(temp->next!=NULL){
        temp = temp->next;
    }
    temp->next=n;
    n->prev=temp;
}

void display(node* head){
    node* temp = head;
    while(temp!=NULL){
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

int main(){
    node* head = NULL;
    insertatTail(head,1);
    insertatTail(head,2);
    insertatTail(head,3);
    insertatTail(head,4);
    insertatTail(head,5);
    insertatHead(head,7);
    display(head);
    deletion(head,1);
    display(head);
    return 0;
}