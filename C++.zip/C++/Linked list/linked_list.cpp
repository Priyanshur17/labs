#include<bits/stdc++.h>
#include<iostream>
using namespace std;

class Node{
    public:
     int value;
     Node* next;
};
int main(){
    Node* head;
    Node* one;
    Node* two;
    Node* three;

    one= new Node();
    two= new Node();
    three= new Node();

    one->value= 2;
    two->value=3;
    three->value=4;

    one->next=two;
    two->next=three;
    three->next= NULL;

    head = one;
    while(head != NULL){
        cout<<head->value ;
        head = head->next;
    }
}
