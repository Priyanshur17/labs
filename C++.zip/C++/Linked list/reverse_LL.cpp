#include<iostream>
#include<bits/stdc++.h>
using namespace std;

class node{
    public:
    int data;
    node* next;

    node(int value){
        data = value;
        next = NULL;
    }
    
};
class Pair{
    public:
    node* head;
    node* tail;
};

Pair reverse_LL(node* head){
    if(head==NULL || head->next==NULL){
        Pair ans;
        ans.head=head;
        ans.tail=head;
        return ans;
    }
    Pair smallans=reverse_LL(head->next);
    smallans.tail->next=head;
    head->next=NULL;
    Pair ans;
    ans.head=smallans.head;
    ans.tail=head;
    return ans;
}
node* reverseLL(node* head){
    Pair ans=reverse_LL(head);
    return ans.head;
}
node* reverseRecursive(node* &head){
    if(head==NULL || head->next==NULL){
        return head;
    }
    node* newhead=reverseRecursive(head->next);
    head->next->next=head;
    head->next=NULL;
    return newhead;
}

node* reverse(node* &head){
    node* prvptr=NULL;
    node* currptr= head;
    node* nextptr;

    while(currptr!= NULL){
        nextptr= currptr->next;
        currptr->next= prvptr ;

        prvptr= currptr;
        currptr= nextptr;
    }
    return prvptr;
}

void insertatHead(node* &head,int value){
    node* n = new node(value);
    n->next=head;
    head=n;
}
void insertattail( node* &head,int value){
    node* n = new node(value);
    if ( head==NULL){
        head=n;
        return;
    }
    node* temp = head;
    while(temp->next!=NULL){
        temp=temp->next;
    }
    temp->next=n;
}
void displaylist(node* head){
    node* temp = head;
    while(temp!=NULL){
        cout<<temp->data <<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}
int main(){
    node* head = NULL;
    insertattail(head,1);
    insertattail(head,2);
    insertattail(head,3);
    insertattail(head,4);

    displaylist(head);
    node* newhead1 = reverseLL(head);
    displaylist(newhead1);
    return 0;
}